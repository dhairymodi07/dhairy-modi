/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a , l , b , p;//area , length ,breadth, perimeter
    printf("Enter the length of rectangle:");
    scanf("%d %d" , &l,&b);
    a = l*b;
    p = 2*(l + b);
    printf("the area is = %d \n", a);
    printf("the perimeter is = %d", p);
    

    return 0;
}


/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a , pounds;//dollar
    printf("Enter the dollar :");
    scanf("%f" , &a);
    pounds=a/1.458333333;
    printf("The pounds of  %f dollar is :%f" , a , pounds);
    return 0;
}




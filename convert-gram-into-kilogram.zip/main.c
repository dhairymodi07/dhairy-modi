/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a , gram;
    printf("Enter the value of kilogram :");
    scanf("%f" , &a);
    gram = a*1000;
    printf("The gram of %f kilogram = %f" , a , gram); 
    return 0;
}
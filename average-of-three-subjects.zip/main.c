/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a , Total;//a = maths
    int b , Average;//b = physics
    int c;//c = chemistry
    printf("Enter the marks of Maths :");
    scanf("%d" ,&a);
    printf("Enter the marks of Physics :");
    scanf("%d" ,&b);
    printf("Enter the marks of Chemistry :");
    scanf("%d" ,&c);
    
    Total = a + b + c;
    Average = Total/3;
    printf("\n \nThe Total of three subjects are %d\n",Total);
    printf("The Avarege of three subjects are %d",Average);
    
     return 0;
}

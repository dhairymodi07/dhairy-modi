/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float net_sales ,gross_sales ; 
    printf("Enter Gross sales :");
    scanf("%f" , &gross_sales);
    
    net_sales = gross_sales - 0.1*gross_sales;
    printf("the net sales is =%f" , net_sales);

    return 0;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float f , celcius;
    printf("Enter the value of fehrenheit :");
    scanf("%f" , &f);
    celcius = (f-32)*5/9 ;
    printf("The value of %f fehrenheit = %f celcius" , f , celcius);
    
    return 0;

    
}

/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a , b , c , d;//a = net salary , b = gross salary , c = allowance , d = deduction
    printf ("Enter Gross salary :");
    scanf("%f" , &b);
    c = b*0.1;
    d = b*0.03;
    a = b + c - d;
    printf("the net salary is = %f" , a);
    return 0;
}
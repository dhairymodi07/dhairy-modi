/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    float a , kilobytes , megabytes , gigabytes ;
    printf("Enter the value of bytes :");
    scanf("%f",&a);
    kilobytes = a/1024;
    megabytes = kilobytes/1024;
    gigabytes = megabytes/1024;
    printf("The value of %f bytes is = %f kilobytes \n", a, kilobytes);
    printf("The value of %f kilonytes is = %f megabytes \n", kilobytes , megabytes);
    printf("The value of %f megabytes is = %f gigabytes \n", megabytes , gigabytes);
     return 0;
}